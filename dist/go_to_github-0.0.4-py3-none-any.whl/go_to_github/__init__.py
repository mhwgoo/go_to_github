"""
`go_to_github` is a tool to test whether `github.com` is reachable right now. If not, it will work it out automatically.
"""

__version__ = "0.0.4"
